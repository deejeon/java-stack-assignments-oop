package com.danieljeon.zookeeper;

/**
 * @author danieljeon
 *
 */
public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla gorilla1 = new Gorilla();
		
		gorilla1.displayEnergy();
		
		gorilla1.throwSomething();
		gorilla1.throwSomething();
		gorilla1.throwSomething();
		gorilla1.displayEnergy();
		
		gorilla1.eatBananas();
		gorilla1.eatBananas();
		gorilla1.displayEnergy();
		
		gorilla1.climb();
		gorilla1.displayEnergy();
	}

}
