package com.danieljeon.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat bat1 = new Bat();
		
		bat1.displayEnergy();
		
		bat1.attackTown();
		bat1.attackTown();
		bat1.attackTown();
		bat1.displayEnergy();
		
		bat1.eatHumans();
		bat1.eatHumans();
		bat1.displayEnergy();
		
		bat1.fly();
		bat1.fly();
		bat1.displayEnergy();
	}

}
